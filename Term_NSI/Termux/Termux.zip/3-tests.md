# IHM mode texte {ignore=true}
> Partie 3 - Jeux de tests.

@import "abstract.md"


## Sommaire de la partie 3 {ignore=true}

[TOC]

*À venir*