Auteur : Franck CHAMBON, enseignant au lycée Lucie AUBRAC de Bollène (84).

@import "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Cc-by-nc-sa_euro_icon.svg/800px-Cc-by-nc-sa_euro_icon.svg.png" {width="100px" title="Licence" alt="Licence CC-BY-NC-SA-4.0"}

Le document suivant est placé sous licence libre [CC - BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/deed.fr)

* Partie 0 : [Installations de Termux](0-termux.html)
* Partie 1 : [Découverte de Bash](1-bash.html)
* Partie 2 : [Édition de code dans un terminal](2-micro.html)
* Partie 3 : [Jeux de tests](3-tests.html)

