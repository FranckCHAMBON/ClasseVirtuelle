# IHM mode texte

**I**nterface **H**umain **M**achine, en mode texte.

@import "abstract.md"


Un document de cours rempli d'exercices destinés aux élèves de NSI ayant une tablette sous Android.

* L'occasion de découvrir les notions de système d'exploitation avec un environnement proche de `bash`.
* D'utiliser un éditeur de code minimaliste, mais  généraliste.
* De travailler avec des scripts simples en Python, et créer des jeux de tests.
* ...


